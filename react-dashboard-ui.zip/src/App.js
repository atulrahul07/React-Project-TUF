
import React from "react";
import ReportCard from "./components/ReportCard";
import MilestoneCard from "./components/MilestoneCard";
import EnrichmentCard from "./components/EnrichmentCard";
import CRMCard from "./components/CRMCard";

export default function App() {
  return (
    <div className="container">
      <ReportCard />
      <div className="grid">
        <MilestoneCard />
        <EnrichmentCard />
        <CRMCard />
      </div>
    </div>
  );
}
