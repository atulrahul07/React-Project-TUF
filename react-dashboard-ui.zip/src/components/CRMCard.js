
import React from "react";

export default function CRMCard() {
  return (
    <div className="card green">
      <h3>Integrated with your CRM</h3>
      <p>Connect and sync product usage data with your CRM.</p>
    </div>
  );
}
