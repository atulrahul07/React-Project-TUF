
import React from "react";

export default function EnrichmentCard() {
  return (
    <div className="card yellow">
      <h3>Automatic enrichment</h3>
      <p>Automatically enrich your customers profiles powered by GPT.</p>
    </div>
  );
}
