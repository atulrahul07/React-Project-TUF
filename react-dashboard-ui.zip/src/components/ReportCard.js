
import React from "react";

export default function ReportCard() {
  return (
    <div className="card report">
      <h2>We automatically generate reports for each of your customers</h2>
    </div>
  );
}
