
import React from "react";

export default function MilestoneCard() {
  return (
    <div className="card purple">
      <h3>Celebrate milestones</h3>
      <p>Instant alerts and weekly digests to keep your team aligned.</p>
    </div>
  );
}
